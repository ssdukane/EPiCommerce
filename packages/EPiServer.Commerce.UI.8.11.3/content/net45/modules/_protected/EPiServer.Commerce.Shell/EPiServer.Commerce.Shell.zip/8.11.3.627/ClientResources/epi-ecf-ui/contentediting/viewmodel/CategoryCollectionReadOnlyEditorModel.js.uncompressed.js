﻿define("epi-ecf-ui/contentediting/viewmodel/CategoryCollectionReadOnlyEditorModel", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

    "../ModelSupport",
    "./ReadOnlyCollectionEditorModel"
],
function (
    //dojo
    declare,
    lang,
    
    ModelSupport,
    ReadOnlyCollectionEditorModel
) {
    return declare([ReadOnlyCollectionEditorModel], {
        // module: 
        //      epi-ecf-ui/contentediting/viewmodel/RelationCollectionEditorModel
        // summary:
        //      Represents the model for RelationCollectionEditor

        _storeKey: "epi.commerce.relation",
        
        createQuery: function (referenceId) {
            return { referenceId: referenceId, relationTypes: [ModelSupport.relationType.node] };
        }
    });
});