﻿define("epi-ecf-ui/component/CatalogNavigationTree", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
// epi
    "epi-cms/component/ContentNavigationTree",
// commerce
    "../widget/viewmodel/CatalogTreeStoreModel",
    "./ContentContextMenuCommandProvider"
],

function (
// dojo
    array,
    declare,
// epi
    ContentNavigationTree,
    // commerce
    CatalogTreeStoreModel,
    ContextMenuCommandProvider
 ) {
    // module:
    //      epi-ecf-ui.component.CatalogNavigationTree

    return declare([ContentNavigationTree], {
        // summary:
        //      Catalog tree component, which support market filtering.
        // tags:
        //      public

        contextMenuCommandProvider: ContextMenuCommandProvider,

        _createTreeModel: function () {
            // summary:
            //      Create content tree model
            // tags:
            //      protected override

            return new CatalogTreeStoreModel({
                root: this.root,
                typeIdentifiers: this.typeIdentifiers,
                containedTypes: this.settings.containedTypes
            });
        }
    });
});