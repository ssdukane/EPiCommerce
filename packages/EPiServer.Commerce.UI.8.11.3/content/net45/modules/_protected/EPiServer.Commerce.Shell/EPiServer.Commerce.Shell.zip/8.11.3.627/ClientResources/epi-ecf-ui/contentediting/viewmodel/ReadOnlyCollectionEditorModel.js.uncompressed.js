﻿define("epi-ecf-ui/contentediting/viewmodel/ReadOnlyCollectionEditorModel", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",

    "epi/dependency",

    // epi cms
    "epi-cms/dgrid/formatters",
    "epi-cms/contentediting/editors/model/CollectionEditorModel"
],
function (
    //dojo
    declare,
    lang,
    when,

    dependency,

    // epi cms
    formatters,
    CollectionEditorModel
) {
    return declare([CollectionEditorModel], {
        // module: 
        //      epi-ecf-ui/contentediting/viewmodel/ReadOnlyCollectionEditorModel
        // summary:
        //      Represents the model for ReadOnly CollectionEditor

        // _storeKey: String
        //      Represents the key to get the store object. Implementation will set this property, to get, for example, price store, or inventory store
        _storeKey: null,

        // _store: Object
        //      Represents the REST store, to get data from.
        _store: null,

        _contentStructureStore : null,

        // _contentLink: ContentReference
        //      Represents the underlay data, a content reference.
        _contentLink: null,
        
        //isInMasterLanguage: Boolean
        //      Represents if the current content link is in master language or not
        isInMasterLanguage: null,

        postscript: function () {
            // summary:
            //      Post script initialization.
            // description:
            //      Set default values.
	    var registry = dependency.resolve("epi.storeregistry");
            this._store = this._store || registry.get(this._storeKey);
            this._contentStructureStore = this._contentStructureStore || registry.get("epi.cms.content.light");
            this.inherited(arguments);
        },

        _dataSetter: function(value) {
            // summary:
            //      Set data property.
            // value: ContentReference
            //      Model value, which would be a ContentReference.
            // tags: 
            //      private

            // The model value is ContentReference. We need to query to the store, to get the appropriate data (for example: price list, or inventory list)
            this._contentLink = value;
            if (!value) {
                this.data = value;
                this._initData();

                return;
            }

            when(this._store.query(this.createQuery(value)), lang.hitch(this, function(storeResult) {
                if (storeResult.models) {
                    this.data = storeResult.models;
                } else {
                    this.data = storeResult;
                }

                this._initData();
            }));

            when(this.getCurrentContent(), lang.hitch(this, function (content) {
                this.set("isInMasterLanguage", content.currentLanguageBranch.isMasterLanguage);
            }));
        },

        _dataGetter: function () {
            // summary:
            //      Get data property.
            // tags: 
            //      private

            return this._contentLink;
        },
        
        createQuery: function(referenceId) {
            return { referenceId: referenceId };
        },
        
        getCurrentContent: function() {
            return this._contentStructureStore.get(this.get("data"));
        },

        generateFormatters: function (columnDefinitions) {
            // summary:
            //      Generate formatters for the specified column definitions.
            // columnDefinitions:
            //      The definition for the columns that should get the generated formatters.
            // tags: 
            //      override

            this.inherited(arguments);

            var typeColumn = columnDefinitions.contentTypeIdentifier;

            if (typeColumn) {
                typeColumn.formatter = lang.hitch(this, formatters.contentIcon);
            }
            // Disable sort order in dgrid
            for (var columnName in columnDefinitions) {
                lang.setObject("sortable", false, columnDefinitions[columnName]);
            }

            return columnDefinitions;
        }
    });
});