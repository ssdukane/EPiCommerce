﻿
tinyMCE.addI18n('sv.epiquote', {
    desc: "Lägg till/redigera citat"
});
