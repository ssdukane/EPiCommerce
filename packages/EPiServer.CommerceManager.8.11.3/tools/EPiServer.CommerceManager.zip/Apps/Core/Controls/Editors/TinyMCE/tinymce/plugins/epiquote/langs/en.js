﻿
tinyMCE.addI18n('en.epiquote', {
    desc: "Insert/edit quote"
});